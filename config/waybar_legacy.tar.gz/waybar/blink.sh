#!/bin/bash
# Dùng với "interval": 1 trong Waybar config — output 1 dòng rồi exit
# Waybar sẽ tự gọi lại mỗi giây, không cần while loop
sec=$(date +%-S)   # %-S bỏ leading zero, tránh bash hiểu 08/09 là octal
if (( sec % 2 == 0 )); then
    echo "● NORMAL"
else
    echo "  NORMAL"
fi
